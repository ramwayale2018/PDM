module.exports = {
    apps: [
      {
        name: 'index',
        script: './index.js',
        env_file: '.env', 
      },
    ],
  };
